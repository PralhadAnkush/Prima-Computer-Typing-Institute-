import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Award,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  ArrowRight,
  Shuffle,
  Flag,
  RotateCcw,
  X,
  HelpCircle,
} from 'lucide-react';
import { LanguageMode } from '../data/curriculum';
import {
  GCC_TBC_OBJECTIVE_QUESTIONS,
  ObjectiveQuestion,
  generateRandomObjectiveSet,
  getQuestionOptions,
  getQuestionText,
} from '../data/objectiveQuestions';
import { playErrorSound, playKeyClick, playSuccessChime } from '../utils/sound';

interface ObjectiveStageProps {
  language: LanguageMode;
  initialSubMode?: 'test' | 'practice';
  soundEnabled: boolean;
}

const TOPICS = ['All', 'Computer', 'Windows', 'Word', 'Excel', 'PowerPoint', 'Internet'] as const;
type TopicFilter = (typeof TOPICS)[number];

export const ObjectiveStage: React.FC<ObjectiveStageProps> = ({
  language,
  initialSubMode = 'test',
  soundEnabled,
}) => {
  const [subMode, setSubMode] = useState<'test' | 'practice'>(initialSubMode);
  const [topicFilter, setTopicFilter] = useState<TopicFilter>('All');

  // 25-Question Test Set (25 Questions, 1 Mark each = 25 Marks total, Passing = 10 Marks, 25 Min timer)
  const [testQuestions, setTestQuestions] = useState<ObjectiveQuestion[]>(() =>
    generateRandomObjectiveSet(25)
  );
  const [practiceQuestions, setPracticeQuestions] = useState<ObjectiveQuestion[]>(() =>
    generateRandomObjectiveSet(25)
  );

  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [showResultModal, setShowResultModal] = useState<boolean>(false);

  useEffect(() => {
    setSubMode(initialSubMode);
  }, [initialSubMode]);

  const activeQuestions = useMemo(() => {
    if (subMode === 'test') {
      return testQuestions;
    }
    if (topicFilter === 'All') {
      return practiceQuestions;
    }
    return GCC_TBC_OBJECTIVE_QUESTIONS.filter((q) => q.topic === topicFilter);
  }, [subMode, testQuestions, practiceQuestions, topicFilter]);

  const currentQuestion = activeQuestions[currentIdx] || activeQuestions[0];

  const handleStartNewTest = useCallback(() => {
    if (subMode === 'test') {
      setTestQuestions(generateRandomObjectiveSet(25));
    } else {
      setPracticeQuestions(generateRandomObjectiveSet(25));
    }
    setCurrentIdx(0);
    setSelectedAnswers({});
    setRevealedAnswers({});
    setElapsedSeconds(0);
    setIsSubmitted(false);
    setShowResultModal(false);
  }, [subMode]);

  const handleResetCurrent = useCallback(() => {
    setCurrentIdx(0);
    setSelectedAnswers({});
    setRevealedAnswers({});
    setElapsedSeconds(0);
    setIsSubmitted(false);
    setShowResultModal(false);
  }, []);

  // 25-Minute (1500s) Countdown Timer in Test Mode
  useEffect(() => {
    if (subMode !== 'test' || isSubmitted) return;
    const interval = window.setInterval(() => {
      setElapsedSeconds((prev) => {
        const next = prev + 1;
        if (next >= 25 * 60) {
          setIsSubmitted(true);
          setShowResultModal(true);
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [subMode, isSubmitted]);

  const handleSelectOption = (optionIdx: number) => {
    if (subMode === 'test' && isSubmitted) return;

    const qId = currentQuestion.id;
    setSelectedAnswers((prev) => ({
      ...prev,
      [qId]: optionIdx,
    }));

    if (soundEnabled) {
      playKeyClick(false);
    }
  };

  const handleCheckPracticeAnswer = () => {
    if (!currentQuestion) return;
    const qId = currentQuestion.id;
    setRevealedAnswers((prev) => ({
      ...prev,
      [qId]: true,
    }));

    const chosen = selectedAnswers[qId];
    if (chosen !== undefined && soundEnabled) {
      if (chosen === currentQuestion.correctIndex) {
        playSuccessChime();
      } else {
        playErrorSound();
      }
    }
  };

  const handleSubmitTest = () => {
    setIsSubmitted(true);
    setShowResultModal(true);
    if (soundEnabled) {
      playSuccessChime();
    }
  };

  // 1 Question = 1 Mark (25 Questions = 25 Marks)
  const stats = useMemo(() => {
    let correct = 0;
    let wrong = 0;
    let attempted = 0;

    for (const q of activeQuestions) {
      const ans = selectedAnswers[q.id];
      if (ans !== undefined) {
        attempted++;
        if (ans === q.correctIndex) {
          correct++;
        } else {
          wrong++;
        }
      }
    }

    const marksObtained = correct * 1;
    const maxMarks = activeQuestions.length * 1;
    const passingMarks = 10; // 10/25 Passing in GCC-TBC Objective
    const passed = marksObtained >= passingMarks;
    const accuracy = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;

    return {
      correct,
      wrong,
      attempted,
      unanswered: activeQuestions.length - attempted,
      marksObtained,
      maxMarks,
      passingMarks,
      passed,
      accuracy,
    };
  }, [activeQuestions, selectedAnswers]);

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const remainingTestSeconds = Math.max(0, 25 * 60 - elapsedSeconds);

  return (
    <div className="flex flex-col gap-3">
      {/* Top Bar: Mode Switch (Test 25M / Practice), Telemetry & Action Buttons */}
      <div className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* Sub-mode Toggle: Test (25Q · 25M) vs Practice */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => {
                setSubMode('test');
                handleStartNewTest();
              }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                subMode === 'test'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Test (25M)
            </button>
            <button
              type="button"
              onClick={() => {
                setSubMode('practice');
                setCurrentIdx(0);
                setIsSubmitted(false);
                setShowResultModal(false);
              }}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                subMode === 'practice'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Practice
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-mono-tabular">
            <span className="text-slate-400">Q:</span>
            <span className="font-bold text-slate-900">
              {currentIdx + 1}/{activeQuestions.length}
            </span>
          </div>

          {/* In Test Mode before submission: Only show Attempted count (NEVER show marks or correct/false ahead of time!) */}
          {subMode === 'test' && !isSubmitted ? (
            <div className="flex items-center gap-1.5 text-xs font-mono-tabular">
              <span className="text-slate-400">Attempted:</span>
              <span className="font-bold text-blue-600">
                {stats.attempted}/{activeQuestions.length}
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-mono-tabular">
              <span className="text-slate-400">Marks:</span>
              <span className="font-bold text-emerald-600">
                {stats.marksObtained}/{stats.maxMarks}
              </span>
            </div>
          )}

          {subMode === 'test' && (
            <div className="flex items-center gap-1.5 text-xs font-mono-tabular">
              <span className="text-slate-400">Time:</span>
              <span className="font-bold text-slate-900">
                {formatTimer(remainingTestSeconds)}
              </span>
            </div>
          )}
        </div>

        {/* Topic Filter in Practice Mode OR Action Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          {subMode === 'practice' && (
            <div className="flex flex-wrap items-center gap-1 mr-1">
              {TOPICS.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setTopicFilter(t);
                    setCurrentIdx(0);
                  }}
                  className={`px-2 py-1 rounded text-xs font-semibold border transition-colors ${
                    topicFilter === t
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            title="Generate 25 Brand New Questions"
            onClick={handleStartNewTest}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-blue-200 bg-blue-50 text-xs font-bold text-blue-700 hover:bg-blue-100 transition-colors cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>New (5K+)</span>
          </button>

          <button
            type="button"
            onClick={handleResetCurrent}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>

          {subMode === 'test' && !isSubmitted && (
            <button
              type="button"
              onClick={handleSubmitTest}
              className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 text-xs font-bold text-white hover:bg-emerald-700 transition-colors shadow-xs"
            >
              <Flag className="w-3.5 h-3.5" />
              <span>Submit</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Question Display & Number Palette */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-start">
        {/* LEFT 8 COLUMNS: Active Question Card */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 flex flex-col justify-between min-h-[380px] shadow-xs">
          <div>
            <div className="flex items-center justify-between gap-2 pb-3 mb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold font-mono">
                  Q{currentIdx + 1}
                </span>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                  {currentQuestion.topic}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-mono-tabular">1 Mark</span>
                {subMode === 'practice' && (
                  <button
                    type="button"
                    onClick={handleCheckPracticeAnswer}
                    disabled={selectedAnswers[currentQuestion.id] === undefined}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold hover:bg-indigo-100 disabled:opacity-40 transition-colors"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>Check Answer</span>
                  </button>
                )}
              </div>
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-slate-900 font-devanagari leading-relaxed mb-6">
              {getQuestionText(currentQuestion, language)}
            </h2>

            {/* 4 Multiple Choice Options (Never revealed beforehand) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {getQuestionOptions(currentQuestion, language).map((opt, optIdx) => {
                const chosenIdx = selectedAnswers[currentQuestion.id];
                const isSelected = chosenIdx === optIdx;
                const isCorrectOption = optIdx === currentQuestion.correctIndex;

                // In Test mode: show feedback ONLY after submission!
                // In Practice mode: show feedback ONLY when user explicitly clicked "Check Answer"!
                const isFeedbackRevealed =
                  (subMode === 'test' && isSubmitted) ||
                  (subMode === 'practice' && revealedAnswers[currentQuestion.id] === true);

                let btnStyle =
                  'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100 hover:border-slate-300';

                if (isFeedbackRevealed) {
                  if (isCorrectOption) {
                    btnStyle = 'bg-emerald-50 border-emerald-500 text-emerald-900 ring-2 ring-emerald-200 font-bold';
                  } else if (isSelected && !isCorrectOption) {
                    btnStyle = 'bg-red-50 border-red-500 text-red-900 ring-2 ring-red-200 font-bold';
                  }
                } else if (isSelected) {
                  // Clean neutral selected state (NO SPOILERS)
                  btnStyle = 'bg-blue-600 border-blue-700 text-white shadow-xs font-bold ring-2 ring-blue-200';
                }

                const optionLetter = ['A', 'B', 'C', 'D'][optIdx];

                return (
                  <button
                    key={optIdx}
                    type="button"
                    onClick={() => handleSelectOption(optIdx)}
                    className={`w-full p-4 rounded-xl border-2 text-left flex items-center justify-between gap-3 transition-all font-devanagari cursor-pointer ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono shrink-0 ${
                          isSelected && !isFeedbackRevealed
                            ? 'bg-white/20 text-white'
                            : 'bg-white border border-slate-200 text-slate-700'
                        }`}
                      >
                        {optionLetter}
                      </span>
                      <span className="text-sm sm:text-base font-semibold break-words">
                        {opt}
                      </span>
                    </div>

                    {isFeedbackRevealed && isCorrectOption && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    )}
                    {isFeedbackRevealed && isSelected && !isCorrectOption && (
                      <XCircle className="w-5 h-5 text-red-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Prev / Next Navigation Bar */}
          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              disabled={currentIdx === 0}
              onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Prev</span>
            </button>

            {currentIdx + 1 < activeQuestions.length ? (
              <button
                type="button"
                onClick={() => setCurrentIdx((i) => Math.min(activeQuestions.length - 1, i + 1))}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
              >
                <span>Next</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              subMode === 'test' && (
                <button
                  type="button"
                  onClick={handleSubmitTest}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-600 text-xs font-bold text-white hover:bg-emerald-700 cursor-pointer shadow-xs"
                >
                  <Flag className="w-4 h-4" />
                  <span>Submit</span>
                </button>
              )
            )}
          </div>
        </div>

        {/* RIGHT 4 COLUMNS: Question Number Palette Grid */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between shadow-xs">
          <div>
            <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-900">Questions (२५ प्रश्न)</span>
              <span className="text-xs font-mono-tabular text-blue-600 font-bold">
                {stats.attempted}/{activeQuestions.length}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-2 max-h-[300px] overflow-y-auto pr-1">
              {activeQuestions.map((q, idx) => {
                const ans = selectedAnswers[q.id];
                const isCurrent = idx === currentIdx;
                const isAnswered = ans !== undefined;
                const isRevealed =
                  (subMode === 'test' && isSubmitted) ||
                  (subMode === 'practice' && revealedAnswers[q.id] === true);
                const isRight = ans === q.correctIndex;

                let pillStyle = 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100';

                if (isCurrent) {
                  pillStyle = 'bg-blue-600 text-white border-blue-700 ring-2 ring-blue-300';
                } else if (isRevealed && isAnswered) {
                  pillStyle = isRight
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300 font-bold'
                    : 'bg-red-50 text-red-700 border-red-300 font-bold';
                } else if (isAnswered) {
                  // Neutral answered indicator during the test (NO COLOR SPOILERS)
                  pillStyle = 'bg-slate-800 text-white border-slate-900 font-bold';
                }

                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => setCurrentIdx(idx)}
                    className={`h-9 rounded-lg border text-xs font-mono font-bold flex items-center justify-center transition-all cursor-pointer ${pillStyle}`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 mt-4 text-[11px] text-slate-500 flex flex-col gap-1.5 font-devanagari">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-blue-600 shrink-0" />
              <span>चालू प्रश्न (Current)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-slate-800 shrink-0" />
              <span>सोडवलेला प्रश्न (Answered)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-slate-100 border border-slate-300 shrink-0" />
              <span>शिल्लक प्रश्न (Remaining)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Result Pop-Up Modal (25 Questions = 25 Marks, Passing = 10 Marks) */}
      {showResultModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center p-4">
          <div className="bg-white border-2 border-blue-600 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div
                  className={`p-2.5 rounded-xl border ${
                    stats.passed
                      ? 'bg-emerald-50 text-emerald-600 border-emerald-200'
                      : 'bg-red-50 text-red-600 border-red-200'
                  }`}
                >
                  <Award className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-extrabold text-slate-900 font-mono-tabular">
                    {stats.passed ? 'PASS' : 'FAIL'} — {stats.marksObtained}/{stats.maxMarks} Marks
                  </h3>
                  <p className="text-xs text-slate-500 font-devanagari mt-0.5">
                    {stats.passed
                      ? 'अभिनंदन! तुम्ही वस्तुनिष्ठ परीक्षा यशस्वीरित्या उत्तीर्ण झालात.'
                      : 'उत्तीर्ण होण्यासाठी किमान १०/२५ गुण आवश्यक आहेत. पुन्हा सराव करा.'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowResultModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 my-4">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Marks</div>
                <div
                  className={`text-xl font-bold font-mono-tabular mt-0.5 ${
                    stats.passed ? 'text-emerald-600' : 'text-red-600'
                  }`}
                >
                  {stats.marksObtained}/{stats.maxMarks}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Correct</div>
                <div className="text-xl font-bold text-emerald-600 font-mono-tabular mt-0.5">
                  {stats.correct}/{activeQuestions.length}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Wrong</div>
                <div className="text-xl font-bold text-red-600 font-mono-tabular mt-0.5">
                  {stats.wrong}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Attempted</div>
                <div className="text-xl font-bold text-blue-600 font-mono-tabular mt-0.5">
                  {stats.attempted}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Accuracy</div>
                <div className="text-xl font-bold text-slate-900 font-mono-tabular mt-0.5">
                  {stats.accuracy}%
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Passing</div>
                <div className="text-xl font-bold text-slate-900 font-mono-tabular mt-0.5">
                  10/{stats.maxMarks}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowResultModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Review Answers
              </button>

              <button
                type="button"
                onClick={handleResetCurrent}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Retry
              </button>

              <button
                type="button"
                onClick={handleStartNewTest}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 text-xs font-bold text-white hover:bg-blue-700 cursor-pointer shadow-xs"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>New Paper</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
