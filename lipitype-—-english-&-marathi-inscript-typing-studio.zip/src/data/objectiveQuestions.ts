import { LanguageMode } from './curriculum';

export interface ObjectiveQuestion {
  id: string;
  topic: 'Computer' | 'Windows' | 'Word' | 'Excel' | 'PowerPoint' | 'Internet';
  questionMr: string;
  optionsMr: [string, string, string, string];
  questionEn: string;
  optionsEn: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanationMr?: string;
  explanationEn?: string;
}

// -------------------------------------------------------------
// CORE AUTHENTIC MSCE GCC-TBC QUESTIONS BANK (60+ Hand-Curated)
// -------------------------------------------------------------
export const GCC_TBC_OBJECTIVE_QUESTIONS: ObjectiveQuestion[] = [
  // Computer Fundamentals
  {
    id: 'q1',
    topic: 'Computer',
    questionMr: 'संगणकाचा मेंदू (Brain of Computer) कशाला म्हणतात?',
    optionsMr: ['RAM', 'CPU', 'Monitor', 'Hard Disk'],
    questionEn: 'Which component is known as the Brain of the Computer?',
    optionsEn: ['RAM', 'CPU', 'Monitor', 'Hard Disk'],
    correctIndex: 1,
    explanationMr: 'CPU (Central Processing Unit) हा संगणकाचा मेंदू मानला जातो, कारण सर्व सूचनांवर प्रक्रिया करणे आणि निर्णय घेण्याचे काम CPU करतो.',
    explanationEn: 'The CPU (Central Processing Unit) acts as the brain of the computer as it executes all instructions and data processing.',
  },
  {
    id: 'q2',
    topic: 'Computer',
    questionMr: 'खालीलपैकी कोणती मेमरी ही तात्पुरती (Volatile) मेमरी आहे?',
    optionsMr: ['ROM', 'RAM', 'Hard Disk', 'Pen Drive'],
    questionEn: 'Which of the following is a volatile (temporary) memory?',
    optionsEn: ['ROM', 'RAM', 'Hard Disk', 'Pen Drive'],
    correctIndex: 1,
  },
  {
    id: 'q3',
    topic: 'Computer',
    questionMr: '१ बाईट (1 Byte) म्हणजे किती बिट्स (Bits) असतात?',
    optionsMr: ['4 Bits', '8 Bits', '16 Bits', '1024 Bits'],
    questionEn: '1 Byte is equal to how many Bits?',
    optionsEn: ['4 Bits', '8 Bits', '16 Bits', '1024 Bits'],
    correctIndex: 1,
  },
  {
    id: 'q4',
    topic: 'Computer',
    questionMr: 'खालीलपैकी कोणते इनपुट डिव्हाइस (Input Device) आहे?',
    optionsMr: ['Printer', 'Speaker', 'Scanner', 'Monitor'],
    questionEn: 'Which of the following is an Input Device?',
    optionsEn: ['Printer', 'Speaker', 'Scanner', 'Monitor'],
    correctIndex: 2,
  },
  {
    id: 'q5',
    topic: 'Computer',
    questionMr: 'CPU चे पूर्ण रूप (Full Form) काय आहे?',
    optionsMr: [
      'Central Process Utility',
      'Central Processing Unit',
      'Computer Processing Unit',
      'Control Processing Unit',
    ],
    questionEn: 'What is the full form of CPU?',
    optionsEn: [
      'Central Process Utility',
      'Central Processing Unit',
      'Computer Processing Unit',
      'Control Processing Unit',
    ],
    correctIndex: 1,
  },
  {
    id: 'q6',
    topic: 'Computer',
    questionMr: '१ किलोबाईट (1 KB) म्हणजे किती बाईट्स?',
    optionsMr: ['1000 Bytes', '1024 Bytes', '1024 Bits', '8 Bytes'],
    questionEn: '1 Kilobyte (1 KB) is equal to how many Bytes?',
    optionsEn: ['1000 Bytes', '1024 Bytes', '1024 Bits', '8 Bytes'],
    correctIndex: 1,
  },
  {
    id: 'q7',
    topic: 'Computer',
    questionMr: 'ALU चे पूर्ण रूप काय आहे?',
    optionsMr: [
      'Arithmetic Logic Unit',
      'Advanced Legal Unit',
      'Auto Line Unit',
      'Access Link Unit',
    ],
    questionEn: 'What is the full form of ALU?',
    optionsEn: [
      'Arithmetic Logic Unit',
      'Advanced Legal Unit',
      'Auto Line Unit',
      'Access Link Unit',
    ],
    correctIndex: 0,
  },
  {
    id: 'q8',
    topic: 'Computer',
    questionMr: 'पहिल्या पिढीतील संगणकांमध्ये मुख्य इलेक्ट्रॉनिक घटक कोणता होता?',
    optionsMr: ['Transistors', 'Vacuum Tubes', 'Integrated Circuits (IC)', 'Microprocessor'],
    questionEn: 'What was the main electronic component in First Generation Computers?',
    optionsEn: ['Transistors', 'Vacuum Tubes', 'Integrated Circuits (IC)', 'Microprocessor'],
    correctIndex: 1,
  },
  {
    id: 'q9',
    topic: 'Computer',
    questionMr: 'खालीलपैकी सर्वात जलद मेमरी कोणती आहे?',
    optionsMr: ['RAM', 'Hard Disk', 'Cache Memory', 'CD-ROM'],
    questionEn: 'Which of the following is the fastest memory in a computer?',
    optionsEn: ['RAM', 'Hard Disk', 'Cache Memory', 'CD-ROM'],
    correctIndex: 2,
  },
  {
    id: 'q10',
    topic: 'Computer',
    questionMr: 'मॉनिटरचा डिस्प्ले मोजण्याचे एकक कोणते?',
    optionsMr: ['Hertz', 'Pixels / Resolution', 'Liters', 'Meters'],
    questionEn: 'What is the unit to measure Monitor screen resolution?',
    optionsEn: ['Hertz', 'Pixels / Resolution', 'Liters', 'Meters'],
    correctIndex: 1,
  },

  // Windows OS
  {
    id: 'q11',
    topic: 'Windows',
    questionMr: 'विंडोजमध्ये फाईल किंवा फोल्डरचे नाव बदलण्यासाठी कोणती शॉर्टकट की आहे?',
    optionsMr: ['F1', 'F2', 'F5', 'F12'],
    questionEn: 'Which shortcut key is used to Rename a file or folder in Windows?',
    optionsEn: ['F1', 'F2', 'F5', 'F12'],
    correctIndex: 1,
  },
  {
    id: 'q12',
    topic: 'Windows',
    questionMr: 'फाईल कायमस्वरूपी (Permanently) डिलीट करण्यासाठी कोणती की वापरतात?',
    optionsMr: ['Delete', 'Ctrl + Delete', 'Shift + Delete', 'Alt + Delete'],
    questionEn: 'Which key combination permanently deletes a file without sending to Recycle Bin?',
    optionsEn: ['Delete', 'Ctrl + Delete', 'Shift + Delete', 'Alt + Delete'],
    correctIndex: 2,
  },
  {
    id: 'q13',
    topic: 'Windows',
    questionMr: 'सर्व चालू विंडो मिनिमाईझ करून डेस्कटॉप दाखवण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['Windows Key + D', 'Windows Key + E', 'Windows Key + R', 'Ctrl + D'],
    questionEn: 'Which shortcut minimizes all open windows and displays the Desktop?',
    optionsEn: ['Windows Key + D', 'Windows Key + E', 'Windows Key + R', 'Ctrl + D'],
    correctIndex: 0,
  },
  {
    id: 'q14',
    topic: 'Windows',
    questionMr: 'विंडोजमध्ये फाईल एक्सप्लोरर (File Explorer) उघडण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['Windows Key + F', 'Windows Key + E', 'Ctrl + E', 'Alt + E'],
    questionEn: 'Which shortcut opens File Explorer in Windows?',
    optionsEn: ['Windows Key + F', 'Windows Key + E', 'Ctrl + E', 'Alt + E'],
    correctIndex: 1,
  },
  {
    id: 'q15',
    topic: 'Windows',
    questionMr: 'चालू प्रोग्राम किंवा विंडो बंद करण्यासाठी कोणता शॉर्टकट वापरतात?',
    optionsMr: ['Ctrl + F4', 'Alt + F4', 'Shift + F4', 'Windows + Q'],
    questionEn: 'Which shortcut is used to close the currently active window or application?',
    optionsEn: ['Ctrl + F4', 'Alt + F4', 'Shift + F4', 'Windows + Q'],
    correctIndex: 1,
  },
  {
    id: 'q16',
    topic: 'Windows',
    questionMr: 'स्क्रीनचा स्क्रीनशॉट घेण्यासाठी कीबोर्डवरील कोणती की वापरतात?',
    optionsMr: ['Print Screen (PrtScn)', 'Scroll Lock', 'Pause Break', 'Insert'],
    questionEn: 'Which keyboard key is used to capture a screenshot of the entire screen?',
    optionsEn: ['Print Screen (PrtScn)', 'Scroll Lock', 'Pause Break', 'Insert'],
    correctIndex: 0,
  },
  {
    id: 'q17',
    topic: 'Windows',
    questionMr: 'विंडोजमध्ये रन (Run) डायलॉग बॉक्स उघडण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['Win + R', 'Win + Run', 'Ctrl + R', 'Alt + R'],
    questionEn: 'Which shortcut key combination opens the Run dialog box in Windows?',
    optionsEn: ['Win + R', 'Win + Run', 'Ctrl + R', 'Alt + R'],
    correctIndex: 0,
  },
  {
    id: 'q18',
    topic: 'Windows',
    questionMr: 'संगणक लॉक करण्यासाठी विंडोज शॉर्टकट कोणता आहे?',
    optionsMr: ['Win + L', 'Ctrl + L', 'Alt + L', 'Shift + L'],
    questionEn: 'Which shortcut locks your Windows computer screen immediately?',
    optionsEn: ['Win + L', 'Ctrl + L', 'Alt + L', 'Shift + L'],
    correctIndex: 0,
  },

  // MS Word
  {
    id: 'q19',
    topic: 'Word',
    questionMr: 'एमएस वर्डमध्ये मजकूर मध्यभागी (Center Align) करण्यासाठी कोणता शॉर्टकट आहे?',
    optionsMr: ['Ctrl + C', 'Ctrl + E', 'Ctrl + M', 'Ctrl + J'],
    questionEn: 'What is the shortcut to Center Align selected text in MS Word?',
    optionsEn: ['Ctrl + C', 'Ctrl + E', 'Ctrl + M', 'Ctrl + J'],
    correctIndex: 1,
  },
  {
    id: 'q20',
    topic: 'Word',
    questionMr: 'एमएस वर्डमध्ये स्पेलिंग व ग्रामर तपासण्यासाठी कोणती फंक्शन की वापरतात?',
    optionsMr: ['F2', 'F5', 'F7', 'F12'],
    questionEn: 'Which function key is used for Spelling & Grammar check in MS Word?',
    optionsEn: ['F2', 'F5', 'F7', 'F12'],
    correctIndex: 2,
  },
  {
    id: 'q21',
    topic: 'Word',
    questionMr: 'वर्ड फाईलचे डीफॉल्ट फाईल एक्स्टेंशन (File Extension) काय असते?',
    optionsMr: ['.txt', '.docx', '.xlsx', '.pptx'],
    questionEn: 'What is the default file extension for MS Word document?',
    optionsEn: ['.txt', '.docx', '.xlsx', '.pptx'],
    correctIndex: 1,
  },
  {
    id: 'q22',
    topic: 'Word',
    questionMr: 'एमएस वर्डमध्ये हायपरलिंक (Hyperlink) जोडण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['Ctrl + H', 'Ctrl + K', 'Ctrl + L', 'Ctrl + P'],
    questionEn: 'Which shortcut key is used to insert a Hyperlink in MS Word?',
    optionsEn: ['Ctrl + H', 'Ctrl + K', 'Ctrl + L', 'Ctrl + P'],
    correctIndex: 1,
  },
  {
    id: 'q23',
    topic: 'Word',
    questionMr: 'नवीन पेज सुरू करण्यासाठी (Page Break) कोणता शॉर्टकट आहे?',
    optionsMr: ['Shift + Enter', 'Ctrl + Enter', 'Alt + Enter', 'Tab + Enter'],
    questionEn: 'What is the shortcut to insert a Page Break in MS Word?',
    optionsEn: ['Shift + Enter', 'Ctrl + Enter', 'Alt + Enter', 'Tab + Enter'],
    correctIndex: 1,
  },
  {
    id: 'q24',
    topic: 'Word',
    questionMr: 'मजकूर जस्टिफाय (Justify) करण्यासाठी कोणता शॉर्टकट वापरतात?',
    optionsMr: ['Ctrl + J', 'Ctrl + L', 'Ctrl + R', 'Ctrl + E'],
    questionEn: 'What is the shortcut key to Justify paragraph text in MS Word?',
    optionsEn: ['Ctrl + J', 'Ctrl + L', 'Ctrl + R', 'Ctrl + E'],
    correctIndex: 0,
  },
  {
    id: 'q25',
    topic: 'Word',
    questionMr: 'वर्डमध्ये फाईल सेव्ह अ‍ॅज (Save As) करण्यासाठी कोणती की वापरतात?',
    optionsMr: ['F10', 'F11', 'F12', 'F9'],
    questionEn: 'Which function key is used for "Save As" in MS Word?',
    optionsEn: ['F10', 'F11', 'F12', 'F9'],
    correctIndex: 2,
  },
  {
    id: 'q26',
    topic: 'Word',
    questionMr: 'एमएस वर्डमध्ये सबस्क्रिप्ट (उदा. H₂O) करण्यासाठी कोणता शॉर्टकट आहे?',
    optionsMr: ['Ctrl + =', 'Ctrl + Shift + +', 'Alt + =', 'Shift + ='],
    questionEn: 'Which shortcut is used to apply Subscript formatting (e.g. H₂O) in Word?',
    optionsEn: ['Ctrl + =', 'Ctrl + Shift + +', 'Alt + =', 'Shift + ='],
    correctIndex: 0,
  },

  // MS Excel
  {
    id: 'q27',
    topic: 'Excel',
    questionMr: 'एमएस एक्सेलमध्ये प्रत्येक फॉर्म्युला (Formula) कोणत्या चिन्हाने सुरू होतो?',
    optionsMr: ['+', '=', '@', '#'],
    questionEn: 'In MS Excel, every formula must begin with which symbol?',
    optionsEn: ['+', '=', '@', '#'],
    correctIndex: 1,
  },
  {
    id: 'q28',
    topic: 'Excel',
    questionMr: 'सेल A1 पासून A10 पर्यंतची बेरीज करण्यासाठी योग्य फॉर्म्युला कोणता?',
    optionsMr: ['=ADD(A1:A10)', '=SUM(A1:A10)', '=TOTAL(A1:A10)', '=COUNT(A1:A10)'],
    questionEn: 'Which formula correctly calculates the sum of cells A1 through A10 in Excel?',
    optionsEn: ['=ADD(A1:A10)', '=SUM(A1:A10)', '=TOTAL(A1:A10)', '=COUNT(A1:A10)'],
    correctIndex: 1,
  },
  {
    id: 'q29',
    topic: 'Excel',
    questionMr: 'एक्सेलमध्ये एका वर्कबुकमध्ये चालू सेलचा पत्ता कुठे दिसतो?',
    optionsMr: ['Formula Bar', 'Name Box', 'Status Bar', 'Title Bar'],
    questionEn: 'Where is the address of the currently active cell displayed in MS Excel?',
    optionsEn: ['Formula Bar', 'Name Box', 'Status Bar', 'Title Bar'],
    correctIndex: 1,
  },
  {
    id: 'q30',
    topic: 'Excel',
    questionMr: 'एक्सेल वर्कशीटमध्ये एकूण किती रोज (Rows) असतात?',
    optionsMr: ['65,536', '1,048,576', '16,384', '256'],
    questionEn: 'How many total rows are there in an MS Excel modern worksheet?',
    optionsEn: ['65,536', '1,048,576', '16,384', '256'],
    correctIndex: 1,
  },
  {
    id: 'q31',
    topic: 'Excel',
    questionMr: 'एक्सेलमध्ये ऑटोसम (AutoSum) करण्यासाठी कोणता शॉर्टकट आहे?',
    optionsMr: ['Alt + =', 'Ctrl + =', 'Shift + =', 'Ctrl + Shift + S'],
    questionEn: 'What is the keyboard shortcut for AutoSum in MS Excel?',
    optionsEn: ['Alt + =', 'Ctrl + =', 'Shift + =', 'Ctrl + Shift + S'],
    correctIndex: 0,
  },
  {
    id: 'q32',
    topic: 'Excel',
    questionMr: 'चालू सेलमधील मजकूर एडिट (Edit) करण्यासाठी कोणती फंक्शन की वापरतात?',
    optionsMr: ['F1', 'F2', 'F4', 'F5'],
    questionEn: 'Which function key is used to edit content in the active cell in Excel?',
    optionsEn: ['F1', 'F2', 'F4', 'F5'],
    correctIndex: 1,
  },
  {
    id: 'q33',
    topic: 'Excel',
    questionMr: 'सेल अ‍ॅबसोल्युट (Absolute Referencing - $A$1) करण्यासाठी कोणती की दाबतात?',
    optionsMr: ['F2', 'F4', 'F8', 'F9'],
    questionEn: 'Which key toggles absolute cell referencing ($A$1) in Excel formula bar?',
    optionsEn: ['F2', 'F4', 'F8', 'F9'],
    correctIndex: 1,
  },

  // MS PowerPoint
  {
    id: 'q34',
    topic: 'PowerPoint',
    questionMr: 'पॉवरपॉईंटमध्ये पहिल्या स्लाईडपासून स्लाईड शो सुरू करण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['F5', 'Shift + F5', 'Ctrl + F5', 'Alt + F5'],
    questionEn: 'Which shortcut starts Slide Show from the first slide in PowerPoint?',
    optionsEn: ['F5', 'Shift + F5', 'Ctrl + F5', 'Alt + F5'],
    correctIndex: 0,
  },
  {
    id: 'q35',
    topic: 'PowerPoint',
    questionMr: 'पॉवरपॉईंट प्रेझेंटेशनमध्ये नवीन स्लाईड (New Slide) इन्सर्ट करण्याचा शॉर्टकट कोणता?',
    optionsMr: ['Ctrl + N', 'Ctrl + M', 'Ctrl + S', 'Ctrl + D'],
    questionEn: 'What is the shortcut key to insert a New Slide in PowerPoint presentation?',
    optionsEn: ['Ctrl + N', 'Ctrl + M', 'Ctrl + S', 'Ctrl + D'],
    correctIndex: 1,
  },
  {
    id: 'q36',
    topic: 'PowerPoint',
    questionMr: 'चालू स्लाईडपासून (Current Slide) स्लाईड शो सुरू करण्यासाठी शॉर्टकट कोणता?',
    optionsMr: ['F5', 'Shift + F5', 'Ctrl + F5', 'Alt + F5'],
    questionEn: 'Which shortcut key starts Slide Show from the Current Slide in PowerPoint?',
    optionsEn: ['F5', 'Shift + F5', 'Ctrl + F5', 'Alt + F5'],
    correctIndex: 1,
  },
  {
    id: 'q37',
    topic: 'PowerPoint',
    questionMr: 'स्लाईड शो थांबवण्यासाठी कीबोर्डवरील कोणती की दाबतात?',
    optionsMr: ['Enter', 'Escape (Esc)', 'Spacebar', 'Ctrl + C'],
    questionEn: 'Which keyboard key is pressed to exit/stop an active Slide Show in PowerPoint?',
    optionsEn: ['Enter', 'Escape (Esc)', 'Spacebar', 'Ctrl + C'],
    correctIndex: 1,
  },
  {
    id: 'q38',
    topic: 'PowerPoint',
    questionMr: 'एका स्लाईडवरून दुसऱ्या स्लाईडवर जाताना होणाऱ्या हालचालीस काय म्हणतात?',
    optionsMr: ['Slide Transition', 'Custom Animation', 'Slide Design', 'Layout'],
    questionEn: 'What is the visual effect called when moving from one slide to another?',
    optionsEn: ['Slide Transition', 'Custom Animation', 'Slide Design', 'Layout'],
    correctIndex: 0,
  },
  {
    id: 'q39',
    topic: 'PowerPoint',
    questionMr: 'निवडलेली स्लाईड डुप्लिकेट (Duplicate Slide) करण्याचा शॉर्टकट कोणता?',
    optionsMr: ['Ctrl + C', 'Ctrl + D', 'Ctrl + M', 'Ctrl + Shift + D'],
    questionEn: 'Which shortcut is used to Duplicate the selected slide in PowerPoint?',
    optionsEn: ['Ctrl + C', 'Ctrl + D', 'Ctrl + M', 'Ctrl + Shift + D'],
    correctIndex: 1,
  },

  // Internet & Email
  {
    id: 'q40',
    topic: 'Internet',
    questionMr: 'ईमेल पाठवताना "Bcc" चे पूर्ण रूप काय आहे?',
    optionsMr: [
      'Blind Carbon Copy',
      'Basic Carbon Copy',
      'Blind Common Copy',
      'Backup Carbon Copy',
    ],
    questionEn: 'What is the full form of "Bcc" in email correspondence?',
    optionsEn: [
      'Blind Carbon Copy',
      'Basic Carbon Copy',
      'Blind Common Copy',
      'Backup Carbon Copy',
    ],
    correctIndex: 0,
  },
  {
    id: 'q41',
    topic: 'Internet',
    questionMr: 'खालीलपैकी कोणता वेब ब्राऊझर (Web Browser) नाही?',
    optionsMr: ['Google Chrome', 'Mozilla Firefox', 'Google Search', 'Microsoft Edge'],
    questionEn: 'Which of the following is NOT a Web Browser?',
    optionsEn: ['Google Chrome', 'Mozilla Firefox', 'Google Search', 'Microsoft Edge'],
    correctIndex: 2,
  },
  {
    id: 'q42',
    topic: 'Internet',
    questionMr: 'URL चे पूर्ण रूप काय आहे?',
    optionsMr: [
      'Uniform Resource Locator',
      'Universal Record Line',
      'United Resource Link',
      'Uniform Real Location',
    ],
    questionEn: 'What is the full form of URL?',
    optionsEn: [
      'Uniform Resource Locator',
      'Universal Record Line',
      'United Resource Link',
      'Uniform Real Location',
    ],
    correctIndex: 0,
  },
  {
    id: 'q43',
    topic: 'Internet',
    questionMr: 'वेबसाईटच्या पत्त्यामध्ये ".in" चा अर्थ काय होतो?',
    optionsMr: ['International', 'India', 'Internet', 'Information'],
    questionEn: 'What does the country code top-level domain ".in" represent?',
    optionsEn: ['International', 'India', 'Internet', 'Information'],
    correctIndex: 1,
  },
  {
    id: 'q44',
    topic: 'Internet',
    questionMr: 'ईमेल पाठवण्यासाठी कोणता प्रोटोकॉल (Protocol) वापरला जातो?',
    optionsMr: ['HTTP', 'SMTP', 'FTP', 'IP'],
    questionEn: 'Which network protocol is used for sending outgoing emails?',
    optionsEn: ['HTTP', 'SMTP', 'FTP', 'IP'],
    correctIndex: 1,
  },
  {
    id: 'q45',
    topic: 'Internet',
    questionMr: 'फाईल ट्रान्सफर करण्यासाठी इंटरनेटवर कोणता प्रोटोकॉल वापरतात?',
    optionsMr: ['HTTP', 'FTP', 'SMTP', 'DNS'],
    questionEn: 'Which protocol is used for transferring files over the Internet?',
    optionsEn: ['HTTP', 'FTP', 'SMTP', 'DNS'],
    correctIndex: 1,
  },
  {
    id: 'q46',
    topic: 'Internet',
    questionMr: 'वेबसाईट सुरक्षित आहे हे ओळखण्यासाठी URL च्या सुरुवातीला काय असावे?',
    optionsMr: ['http://', 'https://', 'www.', 'ftp://'],
    questionEn: 'What prefix indicates that a website connection is secure (encrypted)?',
    optionsEn: ['http://', 'https://', 'www.', 'ftp://'],
    correctIndex: 1,
  },
  {
    id: 'q47',
    topic: 'Internet',
    questionMr: 'इंटरनेटवर नको असलेल्या व्यावसायिक ईमेल मेसेजना काय म्हणतात?',
    optionsMr: ['Draft', 'Spam / Junk', 'Trash', 'Inbox'],
    questionEn: 'Unsolicited and unwanted commercial bulk emails are commonly known as:',
    optionsEn: ['Draft', 'Spam / Junk', 'Trash', 'Inbox'],
    correctIndex: 1,
  },
  {
    id: 'q48',
    topic: 'Computer',
    questionMr: 'GCC-TBC इंग्रजी ३० WPM परीक्षेमध्ये एकूण किती शब्द (Words) टाईप करावे लागतात?',
    optionsMr: ['150 Words', '210 Words', '300 Words', '400 Words'],
    questionEn: 'In GCC-TBC English 30 WPM exam, how many words are required in 7 minutes benchmark?',
    optionsEn: ['150 Words', '210 Words', '300 Words', '400 Words'],
    correctIndex: 1,
  },
  {
    id: 'q49',
    topic: 'Computer',
    questionMr: 'GCC-TBC परीक्षेमध्ये ऑब्जेक्टिव्ह विभागासाठी एकूण किती गुण असतात?',
    optionsMr: ['25 Marks', '40 Marks', '50 Marks', '100 Marks'],
    questionEn: 'In GCC-TBC exam, what is the total mark allocation for 25 Objective questions?',
    optionsEn: ['25 Marks', '40 Marks', '50 Marks', '100 Marks'],
    correctIndex: 0,
  },
  {
    id: 'q50',
    topic: 'Computer',
    questionMr: 'संगणकावर टायपिंग करताना होम रो (Home Row) वरील डाव्या हाताची मूळ स्थिती कोणती?',
    optionsMr: ['A S D F', 'Q W E R', 'Z X C V', 'J K L ;'],
    questionEn: 'What is the correct Home Row resting position for the Left Hand fingers?',
    optionsEn: ['A S D F', 'Q W E R', 'Z X C V', 'J K L ;'],
    correctIndex: 0,
  },
];

// -------------------------------------------------------------
// DYNAMIC PROCEDURAL GENERATION ENGINE (5,000+ Permutations)
// Generates endless authentic GCC-TBC questions covering all domains
// -------------------------------------------------------------

interface ShortcutRule {
  key: string;
  actionMr: string;
  actionEn: string;
  app: 'Word' | 'Excel' | 'PowerPoint' | 'Windows';
}

const SHORTCUT_RULES: ShortcutRule[] = [
  { key: 'Ctrl + C', actionMr: 'कॉपी (Copy) करणे', actionEn: 'Copy selected text or item', app: 'Windows' },
  { key: 'Ctrl + V', actionMr: 'पेस्ट (Paste) करणे', actionEn: 'Paste copied text or item', app: 'Windows' },
  { key: 'Ctrl + X', actionMr: 'कट (Cut) करणे', actionEn: 'Cut selected text or item', app: 'Windows' },
  { key: 'Ctrl + Z', actionMr: 'अनडू (Undo) करणे', actionEn: 'Undo the last action', app: 'Windows' },
  { key: 'Ctrl + Y', actionMr: 'रिडू (Redo) करणे', actionEn: 'Redo the last undone action', app: 'Windows' },
  { key: 'Ctrl + A', actionMr: 'सर्व सिलेक्ट (Select All) करणे', actionEn: 'Select All contents', app: 'Windows' },
  { key: 'Ctrl + S', actionMr: 'दस्तऐवज सेव्ह (Save) करणे', actionEn: 'Save current document', app: 'Word' },
  { key: 'Ctrl + P', actionMr: 'प्रिंट (Print) डायलॉग उघडणे', actionEn: 'Open Print dialog box', app: 'Word' },
  { key: 'Ctrl + B', actionMr: 'मजकूर बोल्ड (Bold) करणे', actionEn: 'Apply Bold formatting', app: 'Word' },
  { key: 'Ctrl + I', actionMr: 'मजकूर इटॅलिक (Italic) करणे', actionEn: 'Apply Italic formatting', app: 'Word' },
  { key: 'Ctrl + U', actionMr: 'मजकुराखाली अंडरलाईन (Underline) देणे', actionEn: 'Apply Underline formatting', app: 'Word' },
  { key: 'Ctrl + F', actionMr: 'मजकूर शोधणे (Find)', actionEn: 'Find text or numbers', app: 'Word' },
  { key: 'Ctrl + H', actionMr: 'मजकूर बदलणे (Replace)', actionEn: 'Find and Replace text', app: 'Word' },
  { key: 'Ctrl + L', actionMr: 'डावीकडे संरेखन (Left Align) करणे', actionEn: 'Left Align text', app: 'Word' },
  { key: 'Ctrl + R', actionMr: 'उजवीकडे संरेखन (Right Align) करणे', actionEn: 'Right Align text', app: 'Word' },
  { key: 'Ctrl + E', actionMr: 'मध्यभागी संरेखन (Center Align) करणे', actionEn: 'Center Align text', app: 'Word' },
  { key: 'Ctrl + J', actionMr: 'मजकूर जस्टिफाय (Justify Align) करणे', actionEn: 'Justify Align paragraph', app: 'Word' },
  { key: 'Ctrl + K', actionMr: 'हायपरलिंक (Hyperlink) जोडणे', actionEn: 'Insert Hyperlink', app: 'Word' },
  { key: 'Ctrl + Enter', actionMr: 'पेज ब्रेक (Page Break) देणे', actionEn: 'Insert Page Break', app: 'Word' },
  { key: 'Alt + F4', actionMr: 'चालू विंडो बंद करणे', actionEn: 'Close active window / Exit program', app: 'Windows' },
  { key: 'Alt + Tab', actionMr: 'चालू प्रोग्राम्समध्ये अदलाबदल करणे', actionEn: 'Switch between open programs', app: 'Windows' },
  { key: 'Windows Key + D', actionMr: 'डेस्कटॉप दाखवणे (Show Desktop)', actionEn: 'Display the desktop directly', app: 'Windows' },
  { key: 'Windows Key + E', actionMr: 'फाईल एक्सप्लोरर उघडणे', actionEn: 'Open File Explorer', app: 'Windows' },
  { key: 'Windows Key + R', actionMr: 'रन डायलॉग (Run Dialog) उघडणे', actionEn: 'Open Run Command dialog', app: 'Windows' },
  { key: 'Windows Key + L', actionMr: 'संगणक लॉक (Lock PC) करणे', actionEn: 'Lock Computer workstation', app: 'Windows' },
  { key: 'F1', actionMr: 'मदत (Help) मिळवणे', actionEn: 'Open Help menu / window', app: 'Windows' },
  { key: 'F2', actionMr: 'फाईल किंवा सेल एडिट / रिनेम करणे', actionEn: 'Rename file or edit active cell', app: 'Windows' },
  { key: 'F5', actionMr: 'रिफ्रेश (Refresh) किंवा स्लाईड शो सुरू करणे', actionEn: 'Refresh window or start slide show', app: 'PowerPoint' },
  { key: 'F7', actionMr: 'स्पेलिंग व ग्रामर तपासणे', actionEn: 'Check Spelling and Grammar', app: 'Word' },
  { key: 'F12', actionMr: 'सेव्ह अ‍ॅज (Save As) करणे', actionEn: 'Open Save As window', app: 'Word' },
  { key: 'Ctrl + M', actionMr: 'पॉवरपॉईंटमध्ये नवीन स्लाईड जोडणे', actionEn: 'Insert New Slide in presentation', app: 'PowerPoint' },
  { key: 'Shift + F5', actionMr: 'चालू स्लाईडपासून शो सुरू करणे', actionEn: 'Start Slide Show from current slide', app: 'PowerPoint' },
  { key: 'Esc', actionMr: 'स्लाईड शो थांबवणे', actionEn: 'Exit or cancel Slide Show', app: 'PowerPoint' },
  { key: 'Alt + =', actionMr: 'एक्सेलमध्ये ऑटोसम (AutoSum) करणे', actionEn: 'AutoSum selected range', app: 'Excel' },
  { key: 'F4', actionMr: 'एक्सेलमध्ये सेल अ‍ॅबसोल्युट ($A$1) करणे', actionEn: 'Toggle absolute cell referencing ($A$1)', app: 'Excel' },
  { key: 'Ctrl + ;', actionMr: 'एक्सेलमध्ये चालू तारीख टाकणे', actionEn: 'Insert current date in active cell', app: 'Excel' },
  { key: 'Ctrl + Shift + :', actionMr: 'एक्सेलमध्ये चालू वेळ टाकणे', actionEn: 'Insert current time in active cell', app: 'Excel' },
];

interface DeviceSpec {
  nameMr: string;
  nameEn: string;
  type: 'Input' | 'Output' | 'Storage';
}

const DEVICES_LIST: DeviceSpec[] = [
  { nameMr: 'कीबोर्ड (Keyboard)', nameEn: 'Keyboard', type: 'Input' },
  { nameMr: 'माऊस (Mouse)', nameEn: 'Mouse', type: 'Input' },
  { nameMr: 'स्कॅनर (Scanner)', nameEn: 'Scanner', type: 'Input' },
  { nameMr: 'वेबकॅम (Webcam)', nameEn: 'Webcam', type: 'Input' },
  { nameMr: 'मायक्रोफोन (Microphone)', nameEn: 'Microphone', type: 'Input' },
  { nameMr: 'बारकोड रीडर (Barcode Reader)', nameEn: 'Barcode Reader', type: 'Input' },
  { nameMr: 'ऑप्टिकल मार्क रीडर (OMR)', nameEn: 'Optical Mark Reader (OMR)', type: 'Input' },
  { nameMr: 'एमआयसीआर (MICR)', nameEn: 'Magnetic Ink Character Reader (MICR)', type: 'Input' },
  { nameMr: 'मॉनिटर (Monitor)', nameEn: 'Monitor (VDU)', type: 'Output' },
  { nameMr: 'प्रिंटर (Printer)', nameEn: 'Printer', type: 'Output' },
  { nameMr: 'प्लॉटर (Plotter)', nameEn: 'Plotter', type: 'Output' },
  { nameMr: 'स्पीकर (Speaker)', nameEn: 'Speaker', type: 'Output' },
  { nameMr: 'प्रोजेक्टर (Projector)', nameEn: 'Projector', type: 'Output' },
  { nameMr: 'हार्ड डिस्क ड्राइव्ह (HDD)', nameEn: 'Hard Disk Drive (HDD)', type: 'Storage' },
  { nameMr: 'सॉलिड स्टेट ड्राइव्ह (SSD)', nameEn: 'Solid State Drive (SSD)', type: 'Storage' },
  { nameMr: 'पेन ड्राइव्ह / फ्लॅश ड्राइव्ह', nameEn: 'Pen Drive / USB Flash Drive', type: 'Storage' },
  { nameMr: 'सीडी-रॉम (CD-ROM)', nameEn: 'Compact Disc (CD-ROM)', type: 'Storage' },
  { nameMr: 'डीव्हीडी (DVD)', nameEn: 'Digital Versatile Disc (DVD)', type: 'Storage' },
];

interface ExtensionSpec {
  ext: string;
  fileTypeMr: string;
  fileTypeEn: string;
  topic: 'Word' | 'Excel' | 'PowerPoint' | 'Windows';
}

const EXTENSIONS_LIST: ExtensionSpec[] = [
  { ext: '.docx', fileTypeMr: 'एमएस वर्ड डॉक्युमेंट (MS Word)', fileTypeEn: 'MS Word Document', topic: 'Word' },
  { ext: '.xlsx', fileTypeMr: 'एमएस एक्सेल वर्कबुक (MS Excel)', fileTypeEn: 'MS Excel Workbook', topic: 'Excel' },
  { ext: '.pptx', fileTypeMr: 'एमएस पॉवरपॉईंट प्रेझेंटेशन (MS PowerPoint)', fileTypeEn: 'MS PowerPoint Presentation', topic: 'PowerPoint' },
  { ext: '.txt', fileTypeMr: 'नोटपॅड टेक्स्ट फाईल (Notepad Plain Text)', fileTypeEn: 'Notepad Plain Text File', topic: 'Windows' },
  { ext: '.pdf', fileTypeMr: 'पोर्टेबल डॉक्युमेंट फॉरमॅट (PDF)', fileTypeEn: 'Portable Document Format (PDF)', topic: 'Windows' },
  { ext: '.jpg / .png', fileTypeMr: 'इमेज / फोटो फाईल', fileTypeEn: 'Image / Picture File', topic: 'Windows' },
  { ext: '.mp3', fileTypeMr: 'ऑडिओ / गाण्याची फाईल', fileTypeEn: 'Audio Sound File', topic: 'Windows' },
  { ext: '.mp4', fileTypeMr: 'व्हिडिओ फाईल', fileTypeEn: 'Video File', topic: 'Windows' },
  { ext: '.zip', fileTypeMr: 'कॉम्प्रेस केलेली झिप फाईल (Compressed)', fileTypeEn: 'Compressed Archive File', topic: 'Windows' },
  { ext: '.exe', fileTypeMr: 'एक्झिक्युटेबल प्रोग्राम फाईल', fileTypeEn: 'Executable Application File', topic: 'Windows' },
];

interface ExcelFormulaSpec {
  func: string;
  descriptionMr: string;
  descriptionEn: string;
  example: string;
}

const EXCEL_FORMULAS: ExcelFormulaSpec[] = [
  { func: '=SUM', descriptionMr: 'संख्यांची बेरीज (Total / Addition) करण्यासाठी', descriptionEn: 'Calculates the total sum of numbers in a range', example: '=SUM(B2:B10)' },
  { func: '=AVERAGE', descriptionMr: 'संख्यांची सरासरी (Average) काढण्यासाठी', descriptionEn: 'Calculates the arithmetic mean / average of numbers', example: '=AVERAGE(C1:C20)' },
  { func: '=MAX', descriptionMr: 'रेंजमधील सर्वात मोठी संख्या (Maximum Value) शोधण्यासाठी', descriptionEn: 'Finds the largest value in a range of cells', example: '=MAX(A1:A50)' },
  { func: '=MIN', descriptionMr: 'रेंजमधील सर्वात लहान संख्या (Minimum Value) शोधण्यासाठी', descriptionEn: 'Finds the smallest value in a range of cells', example: '=MIN(A1:A50)' },
  { func: '=COUNT', descriptionMr: 'फक्त संख्या असलेल्या सेल्सची संख्या मोजण्यासाठी', descriptionEn: 'Counts the number of cells that contain numbers', example: '=COUNT(A1:A25)' },
  { func: '=COUNTA', descriptionMr: 'रिक्त नसलेल्या (Non-empty) सर्व सेल्स मोजण्यासाठी', descriptionEn: 'Counts all non-empty cells containing text or numbers', example: '=COUNTA(A1:A30)' },
  { func: '=UPPER', descriptionMr: 'सर्व अक्षरे कॅपिटल (Uppercase) करण्यासाठी', descriptionEn: 'Converts text to all UPPERCASE letters', example: '=UPPER(A1)' },
  { func: '=LOWER', descriptionMr: 'सर्व अक्षरे लहान लिपीत (Lowercase) करण्यासाठी', descriptionEn: 'Converts text to all lowercase letters', example: '=LOWER(A1)' },
  { func: '=PROPER', descriptionMr: 'प्रत्येक शब्दाचे पहिले अक्षर कॅपिटल करण्यासाठी', descriptionEn: 'Capitalizes the first letter of each word in a string', example: '=PROPER(A1)' },
  { func: '=TODAY()', descriptionMr: 'सिस्टीमची चालू तारीख (Current Date) दाखवण्यासाठी', descriptionEn: 'Returns the current system date in a cell', example: '=TODAY()' },
  { func: '=NOW()', descriptionMr: 'चालू तारीख आणि वेळ (Date and Time) दाखवण्यासाठी', descriptionEn: 'Returns both current date and time', example: '=NOW()' },
];

interface MemoryConversionSpec {
  fromUnit: string;
  toUnit: string;
  correctAmount: string;
  wrongOptions: [string, string, string];
}

const MEMORY_CONVERSIONS: MemoryConversionSpec[] = [
  { fromUnit: '1 Nibble', toUnit: 'Bits', correctAmount: '4 Bits', wrongOptions: ['8 Bits', '16 Bits', '2 Bits'] },
  { fromUnit: '1 Byte', toUnit: 'Bits', correctAmount: '8 Bits', wrongOptions: ['4 Bits', '16 Bits', '1024 Bits'] },
  { fromUnit: '1 KB (Kilobyte)', toUnit: 'Bytes', correctAmount: '1024 Bytes', wrongOptions: ['1000 Bytes', '1024 Bits', '8 Bytes'] },
  { fromUnit: '1 MB (Megabyte)', toUnit: 'KB', correctAmount: '1024 KB', wrongOptions: ['1000 KB', '1024 MB', '8 KB'] },
  { fromUnit: '1 GB (Gigabyte)', toUnit: 'MB', correctAmount: '1024 MB', wrongOptions: ['1000 MB', '1024 GB', '100 MB'] },
  { fromUnit: '1 TB (Terabyte)', toUnit: 'GB', correctAmount: '1024 GB', wrongOptions: ['1000 GB', '1024 MB', '500 GB'] },
];

function shuffleOptions<T>(correct: T, wrong: T[]): { options: [T, T, T, T]; correctIndex: 0 | 1 | 2 | 3 } {
  const all = [correct, ...wrong.slice(0, 3)];
  // Fisher-Yates shuffle
  for (let i = all.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [all[i], all[j]] = [all[j], all[i]];
  }
  const correctIndex = all.indexOf(correct) as 0 | 1 | 2 | 3;
  return {
    options: [all[0], all[1], all[2], all[3]],
    correctIndex,
  };
}

/**
 * Procedurally generates dynamic GCC-TBC questions to ensure a pool of 5,000+ unique questions.
 */
export function generateProceduralQuestion(indexSeed: number): ObjectiveQuestion {
  const catChoice = indexSeed % 6;

  // 1. Shortcut Key Question (Question: "Which shortcut does X?" or "What does Shortcut Y do?")
  if (catChoice === 0 || catChoice === 1) {
    const rule = SHORTCUT_RULES[indexSeed % SHORTCUT_RULES.length];
    const reverse = Math.floor(indexSeed / SHORTCUT_RULES.length) % 2 === 0;

    if (reverse) {
      // "What is shortcut for X?"
      const otherKeys = SHORTCUT_RULES.filter((r) => r.key !== rule.key).map((r) => r.key);
      const shuffled = shuffleOptions(rule.key, otherKeys);
      return {
        id: `proc-sc1-${indexSeed}`,
        topic: rule.app,
        questionMr: `संगणकावर '${rule.actionMr}' करण्यासाठी कोणती शॉर्टकट की वापरतात?`,
        optionsMr: shuffled.options,
        questionEn: `Which keyboard shortcut is used to ${rule.actionEn}?`,
        optionsEn: shuffled.options,
        correctIndex: shuffled.correctIndex,
        explanationMr: `'${rule.actionMr}' करण्यासाठी '${rule.key}' ही अधिकृत शॉर्टकट की वापरली जाते (${rule.app}).`,
        explanationEn: `'${rule.key}' is the official keyboard shortcut used to ${rule.actionEn} in ${rule.app}.`,
      };
    } else {
      // "What does key X do?"
      const otherActionsMr = SHORTCUT_RULES.filter((r) => r.key !== rule.key).map((r) => r.actionMr);
      const otherActionsEn = SHORTCUT_RULES.filter((r) => r.key !== rule.key).map((r) => r.actionEn);

      const shuffledEn = shuffleOptions(rule.actionEn, otherActionsEn);
      // Ensure Marathi options align with the same correct index
      const optionsMr = [...shuffledEn.options] as [string, string, string, string];
      optionsMr[shuffledEn.correctIndex] = rule.actionMr;
      let wrongMrIdx = 0;
      for (let i = 0; i < 4; i++) {
        if (i !== shuffledEn.correctIndex) {
          optionsMr[i] = otherActionsMr[wrongMrIdx++] || 'इतर कार्य';
        }
      }

      return {
        id: `proc-sc2-${indexSeed}`,
        topic: rule.app,
        questionMr: `'${rule.key}' या कीबोर्ड शॉर्टकटचा उपयोग कशासाठी होतो?`,
        optionsMr,
        questionEn: `What is the function of the keyboard shortcut '${rule.key}'?`,
        optionsEn: shuffledEn.options,
        correctIndex: shuffledEn.correctIndex,
        explanationMr: `'${rule.key}' दाबल्यास '${rule.actionMr}' हे कार्य घडते (${rule.app}).`,
        explanationEn: `Pressing '${rule.key}' will ${rule.actionEn} in ${rule.app}.`,
      };
    }
  }

  // 2. Hardware Classification (Input / Output / Storage)
  if (catChoice === 2) {
    const targetType: 'Input' | 'Output' | 'Storage' =
      indexSeed % 3 === 0 ? 'Input' : indexSeed % 3 === 1 ? 'Output' : 'Storage';
    const typeLabelMr =
      targetType === 'Input' ? 'इनपुट डिव्हाइस (Input Device)' : targetType === 'Output' ? 'आउटपुट डिव्हाइस (Output Device)' : 'स्टोरेज डिव्हाइस (Storage Device)';
    const typeLabelEn =
      targetType === 'Input' ? 'Input Device' : targetType === 'Output' ? 'Output Device' : 'Storage Device';

    const matches = DEVICES_LIST.filter((d) => d.type === targetType);
    const nonMatches = DEVICES_LIST.filter((d) => d.type !== targetType);

    const chosenMatch = matches[indexSeed % matches.length];
    const otherNamesMr = nonMatches.map((d) => d.nameMr);
    const otherNamesEn = nonMatches.map((d) => d.nameEn);

    const shuffledEn = shuffleOptions(chosenMatch.nameEn, otherNamesEn);
    const optionsMr = [...shuffledEn.options] as [string, string, string, string];
    optionsMr[shuffledEn.correctIndex] = chosenMatch.nameMr;
    let wrongMrIdx = 0;
    for (let i = 0; i < 4; i++) {
      if (i !== shuffledEn.correctIndex) {
        optionsMr[i] = otherNamesMr[wrongMrIdx++] || 'इतर डिव्हाइस';
      }
    }

    return {
      id: `proc-dev-${indexSeed}`,
      topic: 'Computer',
      questionMr: `खालीलपैकी कोणते ${typeLabelMr} चे उदाहरण आहे?`,
      optionsMr,
      questionEn: `Which of the following is an example of an ${typeLabelEn}?`,
      optionsEn: shuffledEn.options,
      correctIndex: shuffledEn.correctIndex,
      explanationMr: `'${chosenMatch.nameMr}' हे ${typeLabelMr} आहे, तर इतर पर्याय वेगळ्या श्रेणीतील डिव्हाइसेस आहेत.`,
      explanationEn: `'${chosenMatch.nameEn}' is classified as an ${typeLabelEn}, whereas the other options belong to different hardware categories.`,
    };
  }

  // 3. File Extensions
  if (catChoice === 3) {
    const extItem = EXTENSIONS_LIST[indexSeed % EXTENSIONS_LIST.length];
    const otherExts = EXTENSIONS_LIST.filter((e) => e.ext !== extItem.ext).map((e) => e.ext);
    const shuffled = shuffleOptions(extItem.ext, otherExts);

    return {
      id: `proc-ext-${indexSeed}`,
      topic: extItem.topic,
      questionMr: `${extItem.fileTypeMr} चे योग्य फाईल एक्स्टेंशन (File Extension) कोणते असते?`,
      optionsMr: shuffled.options,
      questionEn: `What is the standard file extension for a ${extItem.fileTypeEn}?`,
      optionsEn: shuffled.options,
      correctIndex: shuffled.correctIndex,
      explanationMr: `${extItem.fileTypeMr} चे अधिकृत फाईल एक्स्टेंशन '${extItem.ext}' असते. यामुळे संगणक फाईलचा प्रकार ओळखतो.`,
      explanationEn: `The standard extension for a ${extItem.fileTypeEn} is '${extItem.ext}', allowing the OS to associate it with the correct software.`,
    };
  }

  // 4. Excel Functions & Formulas
  if (catChoice === 4) {
    const formulaItem = EXCEL_FORMULAS[indexSeed % EXCEL_FORMULAS.length];
    const otherFuncs = EXCEL_FORMULAS.filter((f) => f.func !== formulaItem.func).map((f) => f.func);
    const shuffled = shuffleOptions(formulaItem.func, otherFuncs);

    return {
      id: `proc-xl-${indexSeed}`,
      topic: 'Excel',
      questionMr: `एमएस एक्सेलमध्ये ${formulaItem.descriptionMr} कोणता फॉर्म्युला / फंक्शन वापरतात?`,
      optionsMr: shuffled.options,
      questionEn: `In MS Excel, which formula/function is used for: ${formulaItem.descriptionEn}?`,
      optionsEn: shuffled.options,
      correctIndex: shuffled.correctIndex,
      explanationMr: `एक्सेलमध्ये ${formulaItem.descriptionMr} '${formulaItem.func}' हे अधिकृत फंक्शन वापरतात (उदा. ${formulaItem.example}).`,
      explanationEn: `In MS Excel, '${formulaItem.func}' is standard for: ${formulaItem.descriptionEn} (syntax: ${formulaItem.example}).`,
    };
  }

  // 5. Memory Conversions & Units
  const memItem = MEMORY_CONVERSIONS[indexSeed % MEMORY_CONVERSIONS.length];
  const shuffled = shuffleOptions(memItem.correctAmount, [...memItem.wrongOptions]);

  return {
    id: `proc-mem-${indexSeed}`,
    topic: 'Computer',
    questionMr: `संगणक मेमरीनुसार ${memItem.fromUnit} म्हणजे किती ${memItem.toUnit}?`,
    optionsMr: shuffled.options,
    questionEn: `According to computer data storage units, ${memItem.fromUnit} is equal to:`,
    optionsEn: shuffled.options,
    correctIndex: shuffled.correctIndex,
    explanationMr: `संगणकीय मेमरीनुसार 1 ${memItem.fromUnit} म्हणजे ${memItem.correctAmount} असते (बायनरी स्टोरेज मानके).`,
    explanationEn: `Under computer binary storage standards, 1 ${memItem.fromUnit} equals ${memItem.correctAmount}.`,
  };
}

/**
 * Generates a brand-new, randomized set of 25 authentic GCC-TBC questions.
 * Draws from both the 60+ core base bank and dynamic procedural generator.
 */
export function generateRandomObjectiveSet(count: number = 25): ObjectiveQuestion[] {
  const chosen: ObjectiveQuestion[] = [];
  const usedQuestions = new Set<string>();

  // 1. First pick 12-15 diverse questions from core verified bank
  const shuffledCore = [...GCC_TBC_OBJECTIVE_QUESTIONS].sort(() => 0.5 - Math.random());
  for (const q of shuffledCore) {
    if (chosen.length >= Math.min(count, 14)) break;
    chosen.push(q);
    usedQuestions.add(q.questionEn);
  }

  // 2. Fill remaining from the dynamic generator using randomized seed offsets
  let seed = Math.floor(Math.random() * 5000);
  while (chosen.length < count) {
    seed += Math.floor(Math.random() * 17) + 1;
    const dynamicQ = generateProceduralQuestion(seed);
    if (!usedQuestions.has(dynamicQ.questionEn)) {
      usedQuestions.add(dynamicQ.questionEn);
      chosen.push(dynamicQ);
    }
  }

  // Final shuffle of the 25 questions
  return chosen.sort(() => 0.5 - Math.random());
}

export function getQuestionText(q: ObjectiveQuestion, lang: LanguageMode): string {
  return lang === 'mr' ? q.questionMr : q.questionEn;
}

export function getQuestionOptions(
  q: ObjectiveQuestion,
  lang: LanguageMode
): [string, string, string, string] {
  return lang === 'mr' ? q.optionsMr : q.optionsEn;
}

// -------------------------------------------------------------
// EXPLANATION / REASON HELPER FOR ALL QUESTIONS (MSCE GCC-TBC)
// -------------------------------------------------------------
const BASE_EXPLANATIONS_MR: Record<string, string> = {
  q1: 'CPU (Central Processing Unit) संगणकातील सर्व गणना, आज्ञा आणि डेटा प्रक्रिया नियंत्रित करतो, म्हणून त्याला संगणकाचा मेंदू म्हणतात.',
  q2: 'RAM (Random Access Memory) ही तात्पुरती (Volatile) मेमरी आहे; संगणकाचा वीज पुरवठा बंद होताच यातील डेटा नष्ट होतो.',
  q3: 'डिजिटल डेटा मोजणीमध्ये ८ बिट्स (Bits) एकत्र येऊन १ बाईट (Byte) तयार होतो.',
  q4: 'स्कॅनर कागदावरील मजकूर किंवा फोटो डिजिटल स्वरूपात संगणकात पाठवतो, म्हणून हे इनपुट डिव्हाइस आहे.',
  q5: 'CPU चे पूर्ण रूप Central Processing Unit असे आहे, जो संगणकाचा मुख्य प्रोसेसर आहे.',
  q6: 'बायनरी मेमरीनुसार २ चा १० वा घात म्हणजेच १०२४ बाईट्स = १ किलोबाईट (1 KB) होते.',
  q7: 'ALU चे पूर्ण रूप Arithmetic Logic Unit असे आहे, जे CPU मध्ये अंकगणितीय व तार्किक प्रक्रिया करते.',
  q8: 'पहिल्या पिढीतील संगणकांमध्ये (1940-1956) व्हॅक्यूम ट्यूब्स (Vacuum Tubes) मुख्य सर्किट घटक म्हणून वापरल्या जात होत्या.',
  q9: 'कॅश मेमरी (Cache Memory) ही CPU च्या थेट जवळ असणारी अतिजलद तात्पुरती मेमरी असते.',
  q10: 'मॉनिटर स्क्रीनवर दिसणारे चित्र सूक्ष्म ठिपक्यांनी बनलेले असते ज्यांना पिक्सेल (Pixels) किंवा रिझोल्यूशन म्हणतात.',
  q11: 'विंडोजमध्ये फाईल किंवा फोल्डर निवडून F2 दाबल्यास थेट त्याचे नाव बदलता (Rename) येते.',
  q12: 'Shift + Delete दाबल्यास फाईल रिसायकल बिनमध्ये न जाता संगणकातून कायमस्वरूपी नष्ट होते.',
  q13: 'Windows Key + D दाबल्यास सर्व चालू विंडो लगेच मिनिमाईझ होऊन डेस्कटॉप उघडतो.',
  q14: 'Windows Key + E ही शॉर्टकट की फाईल एक्सप्लोरर (My Computer / This PC) उघडण्यासाठी वापरली जाते.',
  q15: 'Alt + F4 हा युनिव्हर्सल शॉर्टकट चालू ॲप्लिकेशन किंवा विंडो बंद करण्यासाठी वापरला जातो.',
  q16: 'Print Screen (PrtScn) की दाबल्यास संपूर्ण स्क्रीनचा फोटो क्लिपबोर्डवर कॉपी होतो.',
  q17: 'Win + R दाबल्यास Windows Run कमांड डायलॉग बॉक्स उघडतो.',
  q18: 'Win + L ही संगणक लॉक करण्याची अधिकृत की आहे, ज्यामुळे दुसऱ्या कोणालाही पासवर्डशिवाय स्क्रीन उघडता येत नाही.',
  q19: 'Ctrl + E मजकूर डाव्या किंवा उजव्या बाजूऐवजी पानावर अगदी मध्यभागी (Center Align) करण्यासाठी वापरतात.',
  q20: 'F7 ही फंक्शन की वर्डमध्ये स्पेलिंग आणि व्याकरणाच्या चुका (Spelling & Grammar Check) शोधण्यासाठी आहे.',
  q21: 'वर्ड २००७ आणि पुढील सर्व आवृत्त्यांचे डीफॉल्ट फाईल एक्स्टेंशन .docx असते.',
  q22: 'Ctrl + K ही हायपरलिंक (Hyperlink) टाकण्यासाठी वापरली जाणारी प्रमाणित शॉर्टकट की आहे.',
  q23: 'Ctrl + Enter दाबल्यास चालू जागेवरून नवीन पान (Page Break) सुरू होते.',
  q24: 'Ctrl + J दाबल्यास परिच्छेदातील ओळी डाव्या आणि उजव्या दोन्ही बाजूंनी समान सरळ रेषेत (Justify) होतात.',
  q25: 'F12 दाबल्यास चालू फाईल नवीन नावाने किंवा नवीन जागेवर सेव्ह (Save As) करण्याचा बॉक्स उघडतो.',
  q26: 'Ctrl + = हा सबस्क्रिप्ट (उदा. H₂O) चा शॉर्टकट आहे, तर Ctrl + Shift + + हा सुपरस्क्रिप्ट (उदा. X²) चा शॉर्टकट आहे.',
  q27: 'एक्सेलमध्ये कोणतीही गणना किंवा फॉर्म्युला सुरू करताना प्रथम = (Equal To) चिन्ह देणे बंधनकारक असते.',
  q28: '=SUM(A1:A10) हे फंक्शन A1 ते A10 या संपूर्ण रेंजमधील सर्व अंकांची बेरीज करते.',
  q29: 'फॉर्म्युला बारच्या डाव्या बाजूस असणाऱ्या नेम बॉक्स (Name Box) मध्ये चालू सक्रिय सेलचा पत्ता (उदा. A1, C5) दिसतो.',
  q30: 'आधुनिक एक्सेल वर्कशीटमध्ये एकूण १०,४८,५७६ रोज (Rows) आणि १६,३८४ कॉलम्स (Columns) असतात.',
  q31: 'Alt + = दाबल्यास एक्सेल आपोआप लगतच्या संख्या ओळखून AutoSum फॉर्म्युला इन्सर्ट करतो.',
  q32: 'F2 दाबल्यास निवडलेला सेल एडिट मोडमध्ये जातो, ज्यामुळे सेलमधील मजकूर दुरुस्त करता येतो.',
  q33: 'फॉर्म्युला बारमध्ये सेल निवडून F4 दाबल्यास सेल पत्ता लॉक होतो ($A$1 Absolute Referencing).',
  q34: 'F5 दाबल्यास पॉवरपॉईंट प्रेझेंटेशन पहिल्या स्लाईडपासून फुल स्क्रीन स्लाईड शो सुरू होतो.',
  q35: 'पॉवरपॉईंटमध्ये Ctrl + M दाबल्यास चालू प्रेझेंटेशनमध्ये नवीन स्लाईड (New Slide) ॲड होते.',
  q36: 'Shift + F5 ही शॉर्टकट की चालू असलेल्या (Current) स्लाईडपासून शो सुरू करण्यासाठी वापरली जाते.',
  q37: 'स्लाईड शो चालू असताना Escape (Esc) की दाबल्यास स्लाईड शो त्वरित थांबतो आणि सामान्य व्ह्यू येतो.',
  q38: 'एका स्लाईडवरून दुसऱ्या स्लाईडवर जाताना होणाऱ्या हालचालीस स्लाईड ट्रान्झिशन (Slide Transition) म्हणतात.',
  q39: 'Ctrl + D दाबल्यास निवडलेली स्लाईड त्वरित डुप्लिकेट (Duplicate) होते.',
  q40: 'Bcc म्हणजे Blind Carbon Copy. यातील ईमेल पत्ते इतर कोणत्याही प्राप्तकर्त्याला दिसत नाहीत.',
  q41: 'गुगल सर्च हे सर्च इंजिन (Search Engine) आहे, वेब ब्राऊझर नाही (गुगल क्रोम हा ब्राऊझर आहे).',
  q42: 'URL चे पूर्ण रूप Uniform Resource Locator असे आहे, जो इंटरनेटवरील पानाचा किंवा फाईलचा निश्चित पत्ता असतो.',
  q43: '.in हा भारताचा अधिकृत कंट्री कोड टॉप-लेव्हल डोमेन (ccTLD) आहे.',
  q44: 'SMTP (Simple Mail Transfer Protocol) चा वापर इंटरनेटवर ईमेल पाठवण्यासाठी (Outgoing Mail) होतो.',
  q45: 'FTP (File Transfer Protocol) चा उपयोग इंटरनेटवर नेटवर्कद्वारे फाईल्स पाठवण्यासाठी व मिळवण्यासाठी होतो.',
  q46: 'https:// मधील "s" चा अर्थ Secure (SSL/TLS Encryption) असा होतो, ज्यामुळे माहिती सुरक्षित राहते.',
  q47: 'न मागवता मोठ्या प्रमाणात पाठवल्या जाणाऱ्या नको असलेल्या मेल्सना स्पॅम किंवा जंक मेल (Spam / Junk) म्हणतात.',
  q48: 'GCC-TBC इंग्रजी ३० WPM परीक्षेमध्ये ७ मिनिटांत २१० शब्द टाईप करणे आवश्यक असते.',
  q49: 'GCC-TBC शासनमान्य संगणक टायपिंग परीक्षेमध्ये २५ वस्तुनिष्ठ प्रश्नांसाठी एकूण २५ गुण असतात (प्रत्येकी १ गुण).',
  q50: 'टायपिंगमध्ये डाव्या हाताची करंगळी, अनामिका, मध्यमा आणि तर्जनी अनुक्रमे A S D F या होम रो कीजवर असतात.',
};

const BASE_EXPLANATIONS_EN: Record<string, string> = {
  q1: 'The CPU (Central Processing Unit) executes instructions, calculates data, and controls overall hardware, earning the title "Brain of the Computer".',
  q2: 'RAM (Random Access Memory) is volatile temporary storage whose data is instantly cleared once power is turned off.',
  q3: 'In binary architecture, 8 bits group together to form exactly 1 Byte.',
  q4: 'A scanner captures optical data and transfers it digitally to the PC, classifying it as an Input device.',
  q5: 'CPU stands for Central Processing Unit, the primary computational engine.',
  q6: 'In computer science base-2 binary math, 2^10 = 1024 Bytes make 1 Kilobyte (1 KB).',
  q7: 'ALU stands for Arithmetic Logic Unit, the internal CPU unit performing mathematical operations and logical evaluations.',
  q8: 'First generation computers (1940s-1950s) relied on vacuum tubes for digital logic and circuitry.',
  q9: 'Cache memory is ultra-high-speed memory integrated directly on or beside the CPU core.',
  q10: 'Monitor sharpness and display dimensions are measured in pixels / screen resolution.',
  q11: 'Pressing F2 while selecting any file or folder immediately opens the Rename mode.',
  q12: 'Shift + Delete bypasses the Recycle Bin and deletes the file permanently from storage.',
  q13: 'Windows Key + D minimizes all active applications and shows the clean Desktop instantly.',
  q14: 'Windows Key + E is the quick system shortcut to open File Explorer / This PC.',
  q15: 'Alt + F4 is the standard shortcut to terminate the active window or program.',
  q16: 'The Print Screen (PrtScn) key captures an image of the current screen and stores it in the clipboard.',
  q17: 'Win + R opens the Run dialog box where system commands and programs can be launched.',
  q18: 'Win + L immediately locks your workstation screen, safeguarding confidential information.',
  q19: 'Ctrl + E aligns highlighted paragraph text symmetrically in the center of the margins in MS Word.',
  q20: 'F7 launches the built-in Spelling and Grammar checking tool in MS Word.',
  q21: 'Since Office 2007, Microsoft Word saves files by default with the XML-based .docx extension.',
  q22: 'Ctrl + K is the standard shortcut to insert or edit a Hyperlink in Word documents.',
  q23: 'Ctrl + Enter splits the document at the cursor position and inserts a Page Break.',
  q24: 'Ctrl + J justifies the paragraph, aligning both left and right edges smoothly.',
  q25: 'F12 directly brings up the Save As dialogue box to save the document under a new name or location.',
  q26: 'Ctrl + = applies Subscript formatting (e.g. H2O), lowering the selected character below the baseline.',
  q27: 'All mathematical and logical formulas in Excel must initiate with the equal sign (=).',
  q28: '=SUM(A1:A10) calculates the arithmetic addition of numbers across cells A1 through A10.',
  q29: 'The Name Box located to the left of the formula bar displays the cell reference of the active cell.',
  q30: 'A standard Excel worksheet consists of 1,048,576 rows and 16,384 columns.',
  q31: 'Alt + = automatically detects contiguous numbers and applies the AutoSum formula.',
  q32: 'F2 places the active spreadsheet cell into direct in-cell editing mode.',
  q33: 'F4 locks cell coordinates into absolute references ($A$1) within the formula bar.',
  q34: 'F5 starts the presentation Slide Show from Slide 1 in full-screen mode.',
  q35: 'Ctrl + M inserts a new blank slide into the current presentation deck.',
  q36: 'Shift + F5 initiates the Slide Show from whichever slide is currently active on screen.',
  q37: 'Pressing Escape (Esc) cancels the full-screen Slide Show and returns to normal edit view.',
  q38: 'Slide Transition is the dynamic visual animation effect seen when transitioning from one slide to another.',
  q39: 'Ctrl + D duplicates the currently highlighted slide or shape.',
  q40: 'Bcc stands for Blind Carbon Copy; email addresses in this field are hidden from other recipients.',
  q41: 'Google Search is a search engine service, not a web browser (Google Chrome is the browser).',
  q42: 'URL stands for Uniform Resource Locator, specifying the distinct address of a resource on the web.',
  q43: '.in is the country-code top-level domain (ccTLD) designated for India.',
  q44: 'SMTP (Simple Mail Transfer Protocol) is the standard internet protocol for sending outgoing email.',
  q45: 'FTP (File Transfer Protocol) transfers files between computers across network connections.',
  q46: 'The https:// prefix confirms that data transmission is encrypted via SSL/TLS for security.',
  q47: 'Unsolicited bulk email messages sent across the internet are referred to as Spam or Junk mail.',
  q48: 'In GCC-TBC English 30 WPM examination, candidates must type 210 benchmark words in 7 minutes.',
  q49: 'GCC-TBC Objective examination carries a total of 25 marks (1 mark per question for 25 questions).',
  q50: 'Left hand fingers rest on Home Row keys A (pinky), S (ring), D (middle), and F (index).',
};

export function getQuestionExplanation(q: ObjectiveQuestion, lang: LanguageMode): string {
  if (lang === 'mr') {
    if (q.explanationMr) return q.explanationMr;
    if (BASE_EXPLANATIONS_MR[q.id]) return BASE_EXPLANATIONS_MR[q.id];
    const correctOpt = q.optionsMr[q.correctIndex];
    return `'${correctOpt}' हे योग्य उत्तर आहे. GCC-TBC अभ्यासक्रमानुसार ${q.topic} विषयातील ही प्रमाणित संकल्पना आहे.`;
  } else {
    if (q.explanationEn) return q.explanationEn;
    if (BASE_EXPLANATIONS_EN[q.id]) return BASE_EXPLANATIONS_EN[q.id];
    const correctOpt = q.optionsEn[q.correctIndex];
    return `'${correctOpt}' is the correct answer according to MSCE GCC-TBC ${q.topic} standards.`;
  }
}
